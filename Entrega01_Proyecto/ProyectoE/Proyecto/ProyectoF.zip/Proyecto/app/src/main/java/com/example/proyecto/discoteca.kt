package com.example.proyecto

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class discoteca : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_discoteca)

        val boton1=findViewById<Button>(R.id.menu)
        val boton2=findViewById<Button>(R.id.reserva)
        val boton3=findViewById<Button>(R.id.calificar)
        val boton4=findViewById<Button>(R.id.guia)

        boton1.setOnClickListener{
            val intent= Intent(this, Menu::class.java)
            startActivity(intent)
        }

        boton2.setOnClickListener{
            val intent= Intent(this, reserva::class.java)
            startActivity(intent)
        }

        boton3.setOnClickListener{
            val intent= Intent(this, calificar::class.java)
            startActivity(intent)
        }

        boton4.setOnClickListener{
            val intent2=Intent(this, mapa::class.java)
            startActivity(intent2)
        }
    }
}