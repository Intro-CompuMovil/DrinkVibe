package com.example.proyecto

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class discotecasUbi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_discotecas_ubi)

        val checkBox1=findViewById<CheckBox>(R.id.checkBox) as CheckBox
        val checkBox2=findViewById<CheckBox>(R.id.checkBox2) as CheckBox
        val checkBox3=findViewById<CheckBox>(R.id.checkBox3) as CheckBox
        val checkBox4=findViewById<CheckBox>(R.id.checkBox4) as CheckBox
        val boton=findViewById<Button>(R.id.button2) as Button

        boton.setOnClickListener{
            if(checkBox1.isChecked == true){
                val intent= Intent(this, discoteca::class.java)
                startActivity((intent))
            }else if(checkBox2.isChecked == true){
                val intent= Intent(this, discoteca::class.java)
                startActivity((intent))
            }else if(checkBox3.isChecked == true){
                val intent= Intent(this, discoteca::class.java)
                startActivity((intent))
            }else if(checkBox4.isChecked == true){
                val intent= Intent(this, discoteca::class.java)
                startActivity((intent))
            }
        }
    }
}