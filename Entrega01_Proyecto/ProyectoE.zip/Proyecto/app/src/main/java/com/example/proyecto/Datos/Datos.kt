package com.example.proyecto.Datos

class Datos {
    companion object{
        val  MY_PERMISSION_ACCESS_FINE_LOCATION = 102
    }
}